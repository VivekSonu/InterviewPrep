﻿MyResource resource =new MyResource();
resource.DoWork();
resource.Dispose();

//IEnumerable
List<int> numbers=new List<int> { 1,2,3,4,5};
IEnumerable<int> result=numbers.Where(x=>x>2);

foreach(int x in result)
{
    Console.WriteLine(x);
}

//IQueryable
//using(var context =new AppDbContext())
//{
//    IQueryable<Employee> employee=context.Employees;

//    var result = employees.Where(e => e.salary > 5000);

//    foreach(var emp in result)
//    {
//        Console.WriteLine(emp.Name);
//    }
//}

//IDisposable
class MyResource : IDisposable
{
    public void DoWork()
    {
        Console.WriteLine("Working with resource...");
    }

    public void Dispose()
    {
        Console.WriteLine("Releasing unmaged resources...");
    }
}
//files,db connection,streams
//Differed and immediate