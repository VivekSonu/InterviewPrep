﻿using System;
using System.Threading.Tasks;

public delegate Task Middleware(string name, Func<Task> next);

public class Program
{
    static async Task Main()
    {
        // ===== Startup =====
        Middleware m1 = async (name, next) =>
        {
            Console.WriteLine("[M1] before");
            await next();
            Console.WriteLine("[M1] after");
        };

        Middleware m2 = async (name, next) =>
        {
            Console.WriteLine("[M2] before");
            await next();
            Console.WriteLine("[M2] after");
        };

        Func<string, Task> endpoint = async name =>
        {
            Console.WriteLine($"[ENDPOINT] Hello {name}");
            await Task.CompletedTask;
        };

        Func<string, Task> pipeline = async name =>
        {
            await m1(name, () => m2(name, () => endpoint(name)));
        };

        Console.WriteLine("== Startup done ==");

        // ===== Simulated requests =====
        while (true)
        {
            Console.Write("Enter name (or 'exit'): ");
            var name = Console.ReadLine();

            if (name == "exit")
                break;

            await pipeline(name);
        }
    }
}


//2️⃣ What happens when a request arrives

//When a request comes:

//Client Request
//      ↓
//Kestrel receives it
//      ↓
//Create HttpContext
//      ↓
//Run middleware pipeline
//      ↓
//Call endpoint (controller / minimal API)
//      ↓
//Use DI container to create required services
//      ↓
//Return response


//using System;
//using System.Collections.Generic;

//public enum Lifetime { Singleton, Scoped, Transient }

//public interface IService { Guid Id { get; } }

//public class SingletonService : IService
//{
//    public Guid Id { get; } = Guid.NewGuid();
//    public SingletonService() => Console.WriteLine($"[Singleton] ctor Id={Id}");
//}
//public class ScopedService : IService
//{
//    public Guid Id { get; } = Guid.NewGuid();
//    public ScopedService() => Console.WriteLine($"[Scoped] ctor Id={Id}");
//}
//public class TransientService : IService
//{
//    public Guid Id { get; } = Guid.NewGuid();
//    public TransientService() => Console.WriteLine($"[Transient] ctor Id={Id}");
//}

//public class Scope : IDisposable
//{
//    internal readonly Dictionary<Type, object> ScopedInstances = new();
//    public void Dispose() => Console.WriteLine("[Scope] disposed");
//}

//public class Container
//{
//    private readonly Dictionary<Type, (Func<Scope, object> factory, Lifetime life)> _reg = new();
//    private readonly Dictionary<Type, object> _singletons = new();

//    public void Add<T>(Func<Scope, T> factory, Lifetime life) where T : class
//        => _reg[typeof(T)] = (s => factory(s), life);

//    public T Resolve<T>(Scope scope) where T : class
//    {
//        var (factory, life) = _reg[typeof(T)];
//        if (life == Lifetime.Singleton)
//        {
//            if (!_singletons.TryGetValue(typeof(T), out var inst))
//                _singletons[typeof(T)] = inst = factory(scope);
//            return (T)inst!;
//        }
//        if (life == Lifetime.Scoped)
//        {
//            if (!scope.ScopedInstances.TryGetValue(typeof(T), out var inst))
//                scope.ScopedInstances[typeof(T)] = inst = factory(scope);
//            return (T)inst!;
//        }
//        // Transient
//        return (T)factory(scope)!;
//    }
//}

//// Demo
//public class Program
//{
//    public static void Main()
//    {
//        var c = new Container();
//        c.Add<SingletonService>(_ => new SingletonService(), Lifetime.Singleton);
//        c.Add<ScopedService>(_ => new ScopedService(), Lifetime.Scoped);
//        c.Add<TransientService>(_ => new TransientService(), Lifetime.Transient);

//        Console.WriteLine("== Request 1 ==");
//        using (var scope = new Scope())
//        {
//            var a = c.Resolve<SingletonService>(scope);
//            var b1 = c.Resolve<ScopedService>(scope);
//            var t1 = c.Resolve<TransientService>(scope);
//            var t2 = c.Resolve<TransientService>(scope);
//            Console.WriteLine($"Singleton same Id: {a.Id}");
//            Console.WriteLine($"Scoped Id: {b1.Id}");
//            Console.WriteLine($"Transient 1: {t1.Id}");
//            Console.WriteLine($"Transient 2: {t2.Id} (different)");
//        }

//        Console.WriteLine("== Request 2 ==");
//        using (var scope = new Scope())
//        {
//            var a2 = c.Resolve<SingletonService>(scope);
//            var b2 = c.Resolve<ScopedService>(scope);
//            Console.WriteLine($"Singleton same Id again: {a2.Id}");
//            Console.WriteLine($"Scoped new per request: {b2.Id}");
//        }
//    }
//}