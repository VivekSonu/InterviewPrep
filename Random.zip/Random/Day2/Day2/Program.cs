﻿// See https://aka.ms/new-console-template for more information

int yint;
bool xbool;
Test test=new Test();

yint = 10;
xbool = false;
test.Name = "Test";
test.Age = 30;

int zint = yint;
zint = 20;
Test test2=test;
test2.Name = "Test2";

int inti = 10;
object obj=inti;
int intz=Convert.ToInt32(obj);
public class Test
{
    public string Name { get; set; }
    public int Age { get; set; }
}
