﻿//Solid priciples

public class Invoice
{
    public void CalculateTotal() {  }
    public void SaveToDatabase() {  }
}

public class Invoices
{
    public void CalculateTotal() { }
}

public class InvoiceRepository
{
    public void SaveToDatabase() { }
}

//ocp
public class Discount
{
    public double GetDiscount(string type)
    {
        if (type == "Regular")
            return 10;
        else if (type =="Premium")
            return 20;
        return 0;
    }
}

//Correct 
 public interface IDiscount
{
    double GetDiscount();
}

public class RegularDiscount : IDiscount
{
    public double GetDiscount() => 10;

}

//liskov substio priciple

//Wrong
//public class Payment
//{
//    public virtual void ProcessPayment()
//    {
//        Console.WriteLine("Processing payment...");
//    }

//    public virtual void Refund()
//    {
//        Console.WriteLine("Refund Processed");
//    }
//}

//public class CashOnDelivery : Payment
//{
//    public override void Refund()
//    {
//        throw new NotSupportedException("");
//    }
//}

//correct
public abstract class Payment
{
    public abstract void ProcessPayment();
}

public interface IRefundable
{
    void Refund();
}

public class CreditCardPayment : Payment, IRefundable
{
    public override void ProcessPayment()
    {
        Console.WriteLine("Credit card payment processed");
    }

    public void Refund()
    {
        Console.WriteLine("Credit card refund processed");
    }
}

// Interface segregation principle
//Wrong
public  interface IWorker
{
    void Work();
    void Eat();
}

public class Robot : IWorker
{
    public void Eat()
    {
        throw new NotImplementedException();
    }

    public void Work() { }
}

//Correct
public interface IWork
{
    void Work();
}

public interface IEat
{
    void Eat();
}

public class Human : IWork, IEat
{
    public void Work() { }
    public void Eat() { }
}

public class Robots : IWork
{
    public void Work() { }
}

//Dependecy Inversion Principle
//Depend on abstraction ,not concrete classes

public class EmailService
{
    public void Send() { }
}

public class Notification
{
    private EmailService _email = new EmailService();

    public void Notify()
    {
        _email.Send();
    }
}

//Correct

public interface IMessageService
{
    void Send();
}

public class EmailServices : IMessageService
{
    public void Send() { }
}

public class Notifications
{
    private readonly IMessageService _messageService;
    public Notifications(IMessageService messageService)
    {
        _messageService = messageService;
    }

    public void Notify()
    {
        _messageService.Send();
    }
}


#region Single responsibility principle: There should be only one reason for the class to change
//public class UnitOfWork : IUnitOfWork
//{
//    private readonly ApplicationDbContext _db;
//    public IVillaRepository Villa { get; private set; }
//    public IApplicationUserRepository User { get; private set; }

//    public IVillaNumberRepository VillaNumber { get; private set; }
//    public IBookingRepository Booking { get; set; }
//    public IAmenityRepository Amenity { get; private set; }
//    public UnitOfWork(ApplicationDbContext db)
//    {
//        _db = db;
//        Villa = new VillaRepository(_db);
//        User = new ApplicationUserRepository(_db);
//        Booking = new BookingRepository(_db);
//        VillaNumber = new VillaNumberRepository(_db);
//        Amenity = new AmenityRepository(_db);
//    }

//    public void Save()
//    {
//        _db.SaveChanges();
//    }
//}
#endregion

#region Open for extension but closed for modification
//public class DashboardService : IDashboardService
//{
//    private readonly IUnitOfWork _unitOfWork;
//    static int previousMonth = DateTime.Now.Month == 1 ? 12 : DateTime.Now.Month - 1;
//    readonly DateTime previousMonthStartDate = new(DateTime.Now.Year, previousMonth, 1);
//    readonly DateTime currentMonthStartDate = new(DateTime.Now.Year, DateTime.Now.Month, 1);

//    public DashboardService(IUnitOfWork unitOfWork)
//    {
//        _unitOfWork = unitOfWork;
//    }
//    public async Task<PieChartDto> GetBookingPieChartData()
//    {
//        var totalBookings = _unitOfWork.Booking.GetAll(u => u.BookingDate >= DateTime.Now.AddDays(-30) && (u.Status != SD.StatusPending || u.Status == SD.StatusCancelled));

//        var customerWithOneBooking = totalBookings.GroupBy(b => b.UserId).Where(x => x.Count() == 1).Select(x => x.Key);

//        int bookingsByNewCustomer = customerWithOneBooking.Count();
//        int bookingByReturningCustomer = totalBookings.Count() - bookingsByNewCustomer;

//        PieChartDto pieChartDto = new()
//        {
//            Labels = new string[] { "New Customer Bookings", "Returning Customer Bookings" },
//            Series = new decimal[] { bookingsByNewCustomer, bookingByReturningCustomer },
//        };

//        return pieChartDto;
//    }

//    public async Task<LineChartDto> GetMemberAndBookingLineChartData()
//    {
//        var bookingData = _unitOfWork.Booking.GetAll(u => u.BookingDate >= DateTime.Now.AddDays(-30) &&
//        u.BookingDate.Date <= DateTime.Now)
//            .GroupBy(b => b.BookingDate.Date)
//            .Select(u => new
//            {
//                DateTime = u.Key,
//                NewBookingCount = u.Count()
//            }
//        );

//        var customerData = _unitOfWork.User.GetAll(u => u.CreateAt >= DateTime.Now.AddDays(-30) &&
//        u.CreateAt.Date <= DateTime.Now)
//            .GroupBy(b => b.CreateAt.Date)
//            .Select(u => new
//            {
//                DateTime = u.Key,
//                NewCustomerCount = u.Count()
//            }
//        );

//        var leftJoin = bookingData.GroupJoin(customerData, booking => booking.DateTime, customer => customer.DateTime,
//            (booking, customer) => new
//            {
//                booking.DateTime,
//                booking.NewBookingCount,
//                NewCustomerCount = customer.Select(x => x.NewCustomerCount).FirstOrDefault()
//            }
//            );

//        var rightJoin = customerData.GroupJoin(bookingData, customer => customer.DateTime, booking => booking.DateTime,
//            (customer, booking) => new
//            {
//                customer.DateTime,
//                NewBookingCount = booking.Select(x => x.NewBookingCount).FirstOrDefault(),
//                customer.NewCustomerCount
//            }
//            );

//        var mergeData = leftJoin.Union(rightJoin).OrderBy(x => x.DateTime).ToList();

//        var newBookingData = mergeData.Select(x => x.NewBookingCount).ToArray();
//        var newCustomerData = mergeData.Select(x => x.NewCustomerCount).ToArray();
//        var categories = mergeData.Select(x => x.DateTime.ToString("MM/dd/yyyy")).ToArray();


//        List<CharData> charDataList = new()
//            {
//                new CharData
//                {
//                    Name="New Bookings",
//                    Data=newBookingData
//                },
//                new CharData
//                {
//                    Name="New Members",
//                    Data=newCustomerData
//                },
//            };

//        LineChartDto lineChartDto = new()
//        {
//            Categories = categories,
//            Series = charDataList
//        };

//        return lineChartDto;
//    }

//    public async Task<RadialBarChartDto> GetRegisteredUserChartData()
//    {
//        var totalUsers = _unitOfWork.User.GetAll();

//        var countByCurrentMonth = totalUsers.Count(u => u.CreateAt >= currentMonthStartDate && u.CreateAt <= DateTime.Now);

//        var countByPreviousMonth = totalUsers.Count(u => u.CreateAt >= previousMonthStartDate && u.CreateAt <= currentMonthStartDate);

//        return SD.GetRadialChartDataModel(totalUsers.Count(), countByCurrentMonth, countByPreviousMonth);

//    }

//    public async Task<RadialBarChartDto> GetRevenueChartData()
//    {
//        var totalBookings = _unitOfWork.Booking.GetAll(u => u.Status != SD.StatusPending
//        || u.Status == SD.StatusCancelled);

//        var totalRevenue = Convert.ToInt32(totalBookings.Sum(u => u.TotalCost));

//        var countByCurrentMonth = totalBookings.Where(u => u.BookingDate >= currentMonthStartDate && u.BookingDate <= DateTime.Now).Sum(u => u.TotalCost);

//        var countByPreviousMonth = totalBookings.Where(u => u.BookingDate >= previousMonthStartDate && u.BookingDate <= DateTime.Now).Sum(u => u.TotalCost);
//        return SD.GetRadialChartDataModel(totalRevenue, countByCurrentMonth, countByPreviousMonth);

//    }

//    public async Task<RadialBarChartDto> GetTotalBookingRadialChartData()
//    {
//        var totalBookings = _unitOfWork.Booking.GetAll(u => u.Status != SD.StatusPending
//        || u.Status == SD.StatusCancelled);

//        var countByCurrentMonth = totalBookings.Count(u => u.BookingDate >= currentMonthStartDate && u.BookingDate <= DateTime.Now);

//        var countByPreviousMonth = totalBookings.Count(u => u.BookingDate >= previousMonthStartDate && u.BookingDate <= currentMonthStartDate);

//        return SD.GetRadialChartDataModel(totalBookings.Count(), countByCurrentMonth, countByPreviousMonth);

//    }

//}
#endregion

#region Liskov substitution principal - object should not be forced to implement the function which is it needs not to use

#endregion

#region Interface segregation principal

#endregion

#region Dependecy Inversion Principle - Depend on abstraction ,not concrete classes
//builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
//builder.Services.AddScoped<IDashboardService, DashboardService>();
//builder.Services.AddScoped<IDbInitializer, DbInitializer>();
//builder.Services.AddScoped<IVillaService, VillaService>();
#endregion
