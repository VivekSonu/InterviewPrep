﻿using System;

class Program
{
    delegate void MyHandler(string msg);

    static void SayHello(string msg) => Console.WriteLine($"Hello {msg}");
    static void SayBye(string msg) => Console.WriteLine($"Bye {msg}");
    static void Main()
    {
        //MyHandler h = SayHello;
        //h("Vivek");
        MyHandler h = SayHello;
        h += SayBye;

        h = SayBye;
        h("Vivek");
    }
}