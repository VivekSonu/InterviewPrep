﻿




//Step 5 — Middleware Example
static async Task LoggingMiddleware(Context context, RequestDelegate next)
{
    Console.WriteLine("Logging start");

    await next(context);

    Console.WriteLine("Logging end");
}


//Step 6 — Simulated Program.cs

class Program2
{
    static async Task Main()
    {
        var services = new ServiceContainer();

        services.Register<IUserService, UserService>();

        var app = new AppBuilder();

        app.Use(LoggingMiddleware);

        app.Use(async (ctx, next) =>
        {
            Console.WriteLine("Auth middleware");

            await next(ctx);
        });

        var pipeline = app.Build();

        Console.WriteLine("Application started");

        while (true)
        {
            Console.WriteLine("Request incoming...");
            await pipeline(new Context { Path = "/users" });
        }
    }
}


//Step 1 — Create Service Container
public class ServiceContainer
{
    private Dictionary<Type, Type> services = new();

    public void Register<TInterface, TImplementation>()
    {
        services[typeof(TInterface)] = typeof(TImplementation);
    }

    public object Resolve(Type type)
    {
        if (services.ContainsKey(type))
            return Activator.CreateInstance(services[type]);

        return Activator.CreateInstance(type);
    }
}

//Step 2 — Middleware Delegate
public delegate Task RequestDelegate(Context context);




//Step 3 — Context
public class Context
{
    public string Path { get; set; }
}


//Step 4 — Middleware Builder
public class AppBuilder
{
    private readonly List<Func<RequestDelegate, RequestDelegate>> components
        = new();

    public void Use(Func<Context, RequestDelegate, Task> middleware)
    {
        components.Add(next =>
        {
            return context => middleware(context, next);
        });
    }

    public RequestDelegate Build()
    {
        RequestDelegate app = context =>
        {
            Console.WriteLine("Controller executed");
            return Task.CompletedTask;
        };

        for (int i = components.Count - 1; i >= 0; i--)
        {
            app = components[i](app);
        }

        return app;
    }
}

