
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MiniAspNetSimulation
{
    // ----------------------------
    // Context (similar to HttpContext)
    // ----------------------------
    public class Context
    {
        public string Path { get; set; }
    }

    // ----------------------------
    // Request Delegate
    // ----------------------------
    public delegate Task RequestDelegate(Context context);

    // ----------------------------
    // Simple DI Container
    // ----------------------------
    public class ServiceContainer
    {
        private Dictionary<Type, Type> services = new Dictionary<Type, Type>();

        public void Register<TInterface, TImplementation>()
        {
            services[typeof(TInterface)] = typeof(TImplementation);
        }

        public object Resolve(Type type)
        {
            if (services.ContainsKey(type))
                return Activator.CreateInstance(services[type]);

            return Activator.CreateInstance(type);
        }
    }

    // ----------------------------
    // Application Builder (Middleware pipeline builder)
    // ----------------------------
    public class AppBuilder
    {
        private readonly List<Func<RequestDelegate, RequestDelegate>> components
            = new List<Func<RequestDelegate, RequestDelegate>>();

        public void Use(Func<Context, RequestDelegate, Task> middleware)
        {
            components.Add(next =>
            {
                return context => middleware(context, next);
            });
        }

        public RequestDelegate Build()
        {
            RequestDelegate app = context =>
            {
                Console.WriteLine("Controller executed");
                return Task.CompletedTask;
            };

            for (int i = components.Count - 1; i >= 0; i--)
            {
                app = components[i](app);
            }

            return app;
        }
    }

    // ----------------------------
    // Example Service
    // ----------------------------
    public interface IUserService
    {
        void GetUser();
    }

    public class UserService : IUserService
    {
        public void GetUser()
        {
            Console.WriteLine("UserService: Returning user");
        }
    }

    // ----------------------------
    // Middleware Examples
    // ----------------------------
    public static class Middlewares
    {
        public static async Task LoggingMiddleware(Context context, RequestDelegate next)
        {
            Console.WriteLine("Logging start");

            await next(context);

            Console.WriteLine("Logging end");
        }
    }

    // ----------------------------
    // Simulated Program.cs
    // ----------------------------
    class Program
    {
        static async Task Main()
        {
            // Simulate builder.Services
            var services = new ServiceContainer();
            services.Register<IUserService, UserService>();

            // Simulate app builder
            var app = new AppBuilder();

            // Add middlewares (similar to app.Use)
            app.Use(Middlewares.LoggingMiddleware);

            app.Use(async (ctx, next) =>
            {
                Console.WriteLine("Auth middleware");
                await next(ctx);
            });

            // Build pipeline
            var pipeline = app.Build();

            Console.WriteLine("Application started");
            Console.WriteLine("Program.cs executed only once during startup\n");

            // Simulate incoming requests
            while (true)
            {
                Console.WriteLine("---- Incoming Request ----");

                await pipeline(new Context { Path = "/users" });

                Console.WriteLine();
                Console.WriteLine("Press ENTER to simulate another request...");
                Console.ReadLine();
            }
        }
    }
}
