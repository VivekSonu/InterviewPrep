﻿// See https://aka.ms/new-console-template for more information

BankAccount bn=new BankAccount();
double b=bn.GetBalance();
Console.WriteLine(b);

Employee d=new Developer();
d.Work();


//runtime polymorphism
Payment payment=new CreditCardPayment();
payment.Pay();

//Compile-time polymorphism
//Calculator calc = new Calculator();
//Console.WriteLine(calc.add(2,3);
//Console.WriteLine(calc.add(2,3,4);

//abstract class
Report pdfReport=new PdfReport();
pdfReport.PrintHeader();
pdfReport.GenerateReport();

class Patient
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string MedicalHistory { get; set; }
    public void DisplayInfo()
    {
        Console.WriteLine($"Name:{Name},Age:{Age},Medical:{MedicalHistory}");
    }
}

class BankAccount
{
    private double balance = 1000;
    public double GetBalance()
    {
        return balance;
    }
}


class Employee
{
    public void Work()
    {
        Console.WriteLine("Employee");
    }
}

class Developer : Employee
{
    public virtual void Pay()
    {
        Console.WriteLine("Processing payment");
    }
}

//polymorphism

//Overriding
class Payment
{
    public virtual void Pay()
    {
        Console.WriteLine("Processing payment");
    }
}
class CreditCardPayment:Payment
{
    public override void Pay()
    {
        Console.WriteLine("Processing credit card payment");
    }
}

//Overloading
class Calculator
{
    public int Add(int a, int b)
    {
        return a + b;

    }
    public int Add(int a, int b,int c)
    {
        return a + b+c;

    }
}

//abstract class

abstract class Report
{
    public void PrintHeader()
    {
        Console.WriteLine("Company Confidential Report");
    }

    public abstract void GenerateReport();
}

class PdfReport : Report
{
    public override void GenerateReport()
    {
        Console.WriteLine("Generating pdf");
    }
}

//interface
interface INotification
{
    void Send(string message);
}

class EmailNotification : INotification
{
    public void Send(string message)
    {
        Console.WriteLine("message");
    }
}

class SmsNotification : INotification
{
    public void Send(string message)
    {
        Console.WriteLine("message");
    }
}